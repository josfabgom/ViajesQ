const fs = require('fs');
let code = fs.readFileSync('src/components/AdminView.tsx', 'utf8');

// 1. Add 'calendario' to fetchData
const fetchCalendar = `
      } else if (activeTab === 'calendario') {
        const [tripsRes, driversRes, passRes, placesRes, ratesRes] = await Promise.all([
          axios.get(\`\${API_URL}/trips\`),
          axios.get(\`\${API_URL}/admin/drivers\`),
          axios.get(\`\${API_URL}/admin/passengers\`),
          axios.get(\`\${API_URL}/admin/places\`),
          axios.get(\`\${API_URL}/admin/price-rates\`)
        ]);
        setTrips(tripsRes.data);
        setDrivers(driversRes.data);
        setPassengers(passRes.data);
        setPlaces(placesRes.data);
        setPriceRates(ratesRes.data);
`;
code = code.replace("} else if (activeTab === 'tarifas') {", fetchCalendar + "} else if (activeTab === 'tarifas') {");

// 2. Add 'calendario' to handleSave & handleDelete
// Trip uses the same endpoint logic, but we need to handle trip saves in Calendario. Actually, let's keep Calendario save logic inside CalendarioView component since it needs specific formatting, or we can use handleSave if modalType === 'trip'.
// Let's add 'trip' to handleSave
const saveTripLogic = `
      } else if (modalType === 'trip') {
        if (editingItem) await axios.put(\`\${API_URL}/trips/\${editingItem.id}\`, formData);
        else await axios.post(\`\${API_URL}/trips\`, formData);
`;
code = code.replace("} else if (modalType === 'price_rate') {", saveTripLogic + "} else if (modalType === 'price_rate') {");

const deleteTripLogic = `
      else if (type === 'trip') await axios.delete(\`\${API_URL}/trips/\${id}\`);
`;
code = code.replace("else if (type === 'price_rate')", deleteTripLogic + "      else if (type === 'price_rate')");


// 3. Add Tab button
const tabButton = `<button className={\`admin-tab-btn \${activeTab === 'calendario' ? 'active' : ''}\`} onClick={() => setActiveTab('calendario')}>📅 Calendario</button>`;
code = code.replace("<button className={`admin-tab-btn ${activeTab === 'viajes'", tabButton + "\n        <button className={`admin-tab-btn ${activeTab === 'viajes'");

// 4. Import CalendarioView
code = "import { CalendarioView } from './CalendarioView';\n" + code;

// 5. Render CalendarioView when activeTab === 'calendario'
const renderCalendar = `
      {activeTab === 'calendario' && (
        <CalendarioView 
          trips={trips} 
          drivers={drivers} 
          passengers={passengers} 
          places={places} 
          priceRates={priceRates} 
          openModal={openModal} 
          handleDelete={handleDelete}
        />
      )}
`;
code = code.replace("{activeTab === 'configuracion' && (", renderCalendar + "\n      {activeTab === 'configuracion' && (");

// 6. Add Trip Modal to AdminView (or CalendarioView can provide its own, but AdminView handles modal state)
const tripModal = `
            {modalType === 'trip' && (
              <>
                <div className="form-group" style={{ display: 'flex', gap: '10px' }}>
                  <div style={{ flex: 1 }}>
                    <label>Fecha y Hora</label>
                    <input type="datetime-local" className="form-control" 
                           value={formData.scheduled_time ? new Date(new Date(formData.scheduled_time).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 16) : ''} 
                           onChange={e => setFormData({...formData, scheduled_time: new Date(e.target.value).toISOString()})} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label>Estado</label>
                    <select className="form-control" value={formData.status || ''} onChange={e => setFormData({...formData, status: e.target.value})}>
                      <option value="scheduled">Programado</option>
                      <option value="in_progress">En Curso</option>
                      <option value="completed">Completado</option>
                    </select>
                  </div>
                </div>
                <div className="form-group" style={{ display: 'flex', gap: '10px' }}>
                  <div style={{ flex: 1 }}>
                    <label>Chofer Asignado</label>
                    <select className="form-control" value={formData.driver_id || ''} onChange={e => setFormData({...formData, driver_id: e.target.value})}>
                      <option value="">Selecciona Chofer...</option>
                      {drivers.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                    </select>
                  </div>
                  <div style={{ flex: 1 }}>
                    <label>Pasajero Asignado</label>
                    <select className="form-control" value={formData.passenger_id || ''} onChange={e => setFormData({...formData, passenger_id: e.target.value})}>
                      <option value="">Selecciona Pasajero...</option>
                      {passengers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-group" style={{ display: 'flex', gap: '10px' }}>
                  <div style={{ flex: 1 }}>
                    <label>Origen</label>
                    <select className="form-control" value={formData.origin_place_id || ''} onChange={e => setFormData({...formData, origin_place_id: e.target.value})}>
                      <option value="">Selecciona Origen...</option>
                      {places.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                  <div style={{ flex: 1 }}>
                    <label>Destino</label>
                    <select className="form-control" value={formData.destination_place_id || ''} onChange={e => setFormData({...formData, destination_place_id: e.target.value})}>
                      <option value="">Selecciona Destino...</option>
                      {places.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-group" style={{ display: 'flex', gap: '10px' }}>
                  <div style={{ flex: 1 }}>
                    <label>Distancia (Km)</label>
                    <div style={{ display: 'flex', gap: '5px' }}>
                      <input type="number" step="0.01" className="form-control" value={formData.distance_km || ''} onChange={e => setFormData({...formData, distance_km: e.target.value})} />
                      <button type="button" className="btn btn-secondary" style={{ padding: '0 10px', fontSize: '12px', width: 'auto' }} onClick={() => {
                        const origin = places.find(p => p.id === formData.origin_place_id);
                        const dest = places.find(p => p.id === formData.destination_place_id);
                        if (origin?.lat && dest?.lat) {
                          const dist = calculateDistance(Number(origin.lat), Number(origin.lng), Number(dest.lat), Number(dest.lng));
                          setFormData({...formData, distance_km: dist});
                        } else {
                          showToast('Selecciona origen y destino con ubicaciones válidas primero.', 'error');
                        }
                      }}>Calc</button>
                    </div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <label>Tarifa</label>
                    <select className="form-control" value={formData.price_rate_id || ''} onChange={e => setFormData({...formData, price_rate_id: e.target.value})}>
                      <option value="">Selecciona Tarifa...</option>
                      {priceRates.map(pr => <option key={pr.id} value={pr.id}>{pr.name} (\${parseFloat(pr.price_per_km).toFixed(2)}/km)</option>)}
                    </select>
                  </div>
                </div>
                {formData.distance_km && formData.price_rate_id && (
                  <div style={{ padding: '10px', background: '#f3f4f6', borderRadius: '4px', textAlign: 'right', fontSize: '16px', color: '#111827' }}>
                    Costo Estimado: <strong>\${(parseFloat(formData.distance_km) * parseFloat(priceRates.find(pr => pr.id === formData.price_rate_id)?.price_per_km || 0)).toFixed(2)}</strong>
                  </div>
                )}
              </>
            )}
`;

code = code.replace("{modalType === 'price_rate' && (", tripModal + "\n            {modalType === 'price_rate' && (");

// Modal title for trip
code = code.replace("modalType === 'driver' ? 'Chofer' : modalType === 'passenger' ? 'Pasajero' : modalType === 'vehicle' ? 'Vehículo' : 'Lugar'", "modalType === 'trip' ? 'Viaje' : modalType === 'driver' ? 'Chofer' : modalType === 'passenger' ? 'Pasajero' : modalType === 'vehicle' ? 'Vehículo' : 'Lugar'");

fs.writeFileSync('src/components/AdminView.tsx', code);
console.log('Done');
