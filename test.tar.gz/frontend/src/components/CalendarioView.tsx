import { Calendar, dateFnsLocalizer } from 'react-big-calendar';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfWeek from 'date-fns/startOfWeek';
import getDay from 'date-fns/getDay';
import es from 'date-fns/locale/es';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const locales = {
  'es': es,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

interface CalendarioViewProps {
  trips: any[];
  drivers: any[];
  passengers: any[];
  places: any[];
  priceRates: any[];
  openModal: (type: string, item?: any) => void;
  handleDelete: (type: string, id: string) => void;
}

export function CalendarioView({ trips, openModal }: CalendarioViewProps) {
  // Map trips to calendar events
  const events = trips.map(trip => {
    // If it doesn't have a scheduled_time, fall back to created_at
    const start = new Date(trip.scheduled_time || trip.created_at);
    // Assume trips take 1 hour for display purposes if ended_at is null
    const end = trip.ended_at ? new Date(trip.ended_at) : new Date(start.getTime() + 60 * 60 * 1000);
    
    return {
      id: trip.id,
      title: `${trip.driver_name || 'Sin Chofer'} ➔ ${trip.passenger_name || 'Sin Pasajero'}`,
      start,
      end,
      resource: trip,
    };
  });

  const handleSelectSlot = ({ start }: { start: Date }) => {
    // Convert to ISO string to pass to modal
    openModal('trip', { scheduled_time: start.toISOString(), status: 'scheduled' });
  };

  const handleSelectEvent = (event: any) => {
    openModal('trip', event.resource);
  };

  return (
    <div className="card" style={{ height: '80vh', padding: '15px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <h3>📅 Calendario de Viajes</h3>
        <button className="btn" style={{ width: 'auto', padding: '8px 16px' }} onClick={() => openModal('trip')}>+ Programar Viaje</button>
      </div>
      
      <div style={{ height: 'calc(100% - 60px)' }}>
        <Calendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          style={{ height: '100%', fontFamily: 'Inter, sans-serif' }}
          culture="es"
          messages={{
            next: "Siguiente",
            previous: "Anterior",
            today: "Hoy",
            month: "Mes",
            week: "Semana",
            day: "Día",
            agenda: "Agenda",
            date: "Fecha",
            time: "Hora",
            event: "Viaje",
            noEventsInRange: "No hay viajes programados en este rango.",
          }}
          selectable
          onSelectSlot={handleSelectSlot}
          onSelectEvent={handleSelectEvent}
          eventPropGetter={(event) => {
            let backgroundColor = '#4f46e5'; // scheduled
            if (event.resource.status === 'in_progress') backgroundColor = '#d97706';
            if (event.resource.status === 'completed') backgroundColor = '#059669';
            return { style: { backgroundColor, borderRadius: '4px', border: 'none' } };
          }}
        />
      </div>
      
      <div style={{ marginTop: '15px', display: 'flex', gap: '15px', fontSize: '13px', color: '#666' }}>
        <strong>Leyenda:</strong>
        <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}><div style={{ width: '12px', height: '12px', background: '#4f46e5', borderRadius: '50%' }}></div> Programado</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}><div style={{ width: '12px', height: '12px', background: '#d97706', borderRadius: '50%' }}></div> En Curso</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}><div style={{ width: '12px', height: '12px', background: '#059669', borderRadius: '50%' }}></div> Completado</span>
      </div>
    </div>
  );
}
