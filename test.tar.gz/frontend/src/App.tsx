import { useState, useEffect } from 'react';
import { AdminView } from './components/AdminView';
import { DriverView } from './components/DriverView';
import { LoginPage } from './components/LoginPage';
import axios from 'axios';
import './index.css';

const API_URL = 'http://localhost:3001/api';

function App() {
  const [user, setUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // On mount, check for saved session
  useEffect(() => {
    const savedToken = localStorage.getItem('viajesq_token');
    const savedUser = localStorage.getItem('viajesq_user');
    if (savedToken && savedUser) {
      // Verify token is still valid
      axios.get(`${API_URL}/auth/me`, {
        headers: { Authorization: `Bearer ${savedToken}` }
      }).then(() => {
        setToken(savedToken);
        setUser(JSON.parse(savedUser));
      }).catch(() => {
        // Token expired
        localStorage.removeItem('viajesq_token');
        localStorage.removeItem('viajesq_user');
      }).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }

    // Set axios default auth header globally
    if (savedToken) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${savedToken}`;
    }
  }, []);

  const handleLogin = (loggedUser: any, loggedToken: string) => {
    setUser(loggedUser);
    setToken(loggedToken);
    axios.defaults.headers.common['Authorization'] = `Bearer ${loggedToken}`;
  };

  const handleLogout = () => {
    localStorage.removeItem('viajesq_token');
    localStorage.removeItem('viajesq_user');
    delete axios.defaults.headers.common['Authorization'];
    setUser(null);
    setToken(null);
  };

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #4f46e5, #7c3aed)' }}>
        <div style={{ color: 'white', fontSize: '18px' }}>Cargando ViajesQ...</div>
      </div>
    );
  }

  // Not logged in → show login
  if (!user || !token) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Driver role → show only driver view (no tabs)
  if (user.role === 'driver') {
    return (
      <div className="container">
        <div className="header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1>ViajesQ</h1>
            <p>Bienvenido, {user.name} 👋</p>
          </div>
          <button onClick={handleLogout} style={{
            background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.4)',
            color: 'white', padding: '8px 16px', borderRadius: '8px', cursor: 'pointer', fontSize: '14px'
          }}>
            Cerrar Sesión
          </button>
        </div>
        <DriverView currentDriverId={user.id} />
      </div>
    );
  }

  // Admin role → show full panel with tabs
  return (
    <div className="container">
      <div className="header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1>ViajesQ</h1>
          <p>Panel de Control — {user.name} ({user.role})</p>
        </div>
        <button onClick={handleLogout} style={{
          background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.4)',
          color: 'white', padding: '8px 16px', borderRadius: '8px', cursor: 'pointer', fontSize: '14px'
        }}>
          Cerrar Sesión
        </button>
      </div>
      <AdminView />
    </div>
  );
}

export default App;
