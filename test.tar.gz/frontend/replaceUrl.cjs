const fs = require('fs');
['src/components/AdminView.tsx', 'src/components/DriverView.tsx', 'src/components/LoginPage.tsx'].forEach(file => {
  if(fs.existsSync(file)) {
    let code = fs.readFileSync(file, 'utf8');
    code = code.replace(/const API_URL = 'http:\/\/localhost:3001\/api';/g, 'const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001/api";');
    fs.writeFileSync(file, code);
  }
});
console.log('Replaced');
