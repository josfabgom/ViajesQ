const fs = require('fs');
let code = fs.readFileSync('src/components/AdminView.tsx', 'utf8');

const toastLogic = `
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({message, type});
    setTimeout(() => setToast(null), 3000);
  };
`;
code = code.replace('const [formData, setFormData] = useState<any>({});', 'const [formData, setFormData] = useState<any>({});\n' + toastLogic);

code = code.replace(/alert\((.*?)\);/g, (match, p1) => {
  if (p1.includes('error')) return `showToast(${p1}, 'error');`;
  return `showToast(${p1}, 'success');`;
});

const toastJSX = `
      {toast && (
        <div className="toast-container">
          <div className={\`toast \${toast.type}\`}>
            {toast.type === 'success' ? '✅' : '❌'} {toast.message}
          </div>
        </div>
      )}
`;
code = code.replace('    </div>\n  );\n}', toastJSX + '    </div>\n  );\n}');

code = code.replace(/<td>\{new Date\(trip.created_at\)/g, '<td data-label="Fecha">{new Date(trip.created_at)');
code = code.replace(/<td><strong>\{trip.driver_name\}/g, '<td data-label="Chofer/Vehículo"><strong>{trip.driver_name}');
code = code.replace(/<td>\{trip.passenger_name\}/g, '<td data-label="Pasajero">{trip.passenger_name}');
code = code.replace(/<td>\{trip.origin_address\}/g, '<td data-label="Origen ➔ Destino">{trip.origin_address}');
code = code.replace(/<td>\{trip.distance_km/g, '<td data-label="Km">{trip.distance_km');
code = code.replace(/<td>\s*<span className=\{\`status-badge/g, '<td data-label="Estado">\n                      <span className={`status-badge');

code = code.replace(/<td><strong>\{pr.name\}/g, '<td data-label="Nombre Tarifa"><strong>{pr.name}');
code = code.replace(/<td>\$\{parseFloat/g, '<td data-label="Precio por Km ($)">${parseFloat');

code = code.replace(/<td><strong>\{r.name\}/g, '<td data-label="Nombre Ruta"><strong>{r.name}');
code = code.replace(/<td>\{r.driver_name\}/g, '<td data-label="Chofer">{r.driver_name}');
code = code.replace(/<td>\{r.passenger_name\}/g, '<td data-label="Pasajero">{r.passenger_name}');
code = code.replace(/<td>\{r.origin_name\}/g, '<td data-label="Origen ➔ Destino">{r.origin_name}');
code = code.replace(/<td>\{r.distance_km \?/g, '<td data-label="Distancia">{r.distance_km ?');
code = code.replace(/<td>\s*\{r.price_rate_name \?/g, '<td data-label="Tarifa / Costo">\n                      {r.price_rate_name ?');

// Use a more careful approach for p.name/d.name to avoid collisions
code = code.replace(/<td><strong>\{p\.name\}/g, '<td data-label="Nombre"><strong>{p.name}');
code = code.replace(/<td>\{p\.address\}/g, '<td data-label="Dirección/Referencia">{p.address}');
code = code.replace(/<td>\{p\.phone\}/g, '<td data-label="Teléfono">{p.phone}');
code = code.replace(/<td>\{p\.email\}/g, '<td data-label="Email">{p.email}');

code = code.replace(/<td><strong>\{d\.name\}/g, '<td data-label="Nombre"><strong>{d.name}');
code = code.replace(/<td>\{d\.email\}/g, '<td data-label="Email">{d.email}');
code = code.replace(/<td>\{d\.phone/g, '<td data-label="Teléfono">{d.phone');

code = code.replace(/<td><strong>\{v\.plate\}/g, '<td data-label="Patente"><strong>{v.plate}');
code = code.replace(/<td>\{v\.brand\}/g, '<td data-label="Marca/Modelo">{v.brand}');
code = code.replace(/<td>\{v\.capacity\}/g, '<td data-label="Capacidad">{v.capacity}');

code = code.replace(/<td>\s*<button className="action-btn"/g, '<td data-label="Acciones">\n                      <button className="action-btn"');

fs.writeFileSync('src/components/AdminView.tsx', code);
console.log("Done");
